import tailwindcss from '@tailwindcss/vite';
import react from '@vitejs/plugin-react';
import path from 'path';
import fs from 'fs';
import {defineConfig, Plugin} from 'vite';

function entryFallbackPlugin(): Plugin {
  return {
    name: 'vite-entry-fallback',
    transformIndexHtml(html: string) {
      const hasSrcMain = fs.existsSync(path.resolve(__dirname, 'src/main.tsx'));
      const hasRootMain = fs.existsSync(path.resolve(__dirname, 'main.tsx'));

      if (!hasSrcMain && hasRootMain) {
        return html.replace('/src/main.tsx', '/main.tsx');
      }
      if (hasSrcMain && !hasRootMain) {
        return html.replace('/main.tsx', '/src/main.tsx');
      }
      return html;
    },
  };
}

export default defineConfig(() => {
  const hasSrcMain = fs.existsSync(path.resolve(__dirname, 'src/main.tsx'));
  const hasRootMain = fs.existsSync(path.resolve(__dirname, 'main.tsx'));
  const mainEntry = hasSrcMain ? path.resolve(__dirname, 'src/main.tsx') : path.resolve(__dirname, 'main.tsx');

  return {
    plugins: [react(), tailwindcss(), entryFallbackPlugin()],
    resolve: {
      alias: [
        { find: '@', replacement: path.resolve(__dirname, '.') },
        { find: '/src/main.tsx', replacement: mainEntry },
        { find: '/main.tsx', replacement: mainEntry },
      ],
    },
    server: {
      // HMR is disabled in AI Studio via DISABLE_HMR env var.
      // Do not modifyâfile watching is disabled to prevent flickering during agent edits.
      hmr: process.env.DISABLE_HMR !== 'true',
      // Disable file watching when DISABLE_HMR is true to save CPU during agent edits.
      watch: process.env.DISABLE_HMR === 'true' ? null : {},
    },
  };
});
