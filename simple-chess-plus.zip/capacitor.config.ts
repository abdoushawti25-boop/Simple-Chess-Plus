import type { CapacitorConfig } from '@capacitor/cli';

const config: CapacitorConfig = {
  appId: 'com.simplechess.app',
  appName: 'Simple Chess Plus',
  webDir: 'dist'
};

export default config;
